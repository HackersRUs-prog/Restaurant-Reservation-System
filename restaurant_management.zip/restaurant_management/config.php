<?php
// Common settings 
define('CURRENCY', 'KE'); 
define('CURRENCY_SYMBOL', 'kshs');          
?>
